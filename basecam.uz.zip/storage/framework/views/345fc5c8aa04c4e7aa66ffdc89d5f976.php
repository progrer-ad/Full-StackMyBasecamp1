

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    Project Details
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <strong>Name:</strong> <?php echo e($project->project_name); ?>

                    </div>
                    <div class="mb-3">
                        <strong>Description:</strong> <?php echo e($project->project_about); ?>

                    </div>
                    <!-- Add more details if needed -->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\basecam.uz\resources\views/projects/show.blade.php ENDPATH**/ ?>