<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Full-Stack My Basecamp 1</title>
</head>
<body>
    <div class="asos">
        <div class="login">
            <a href="/login">Login</a>
        </div>
        <div class="sing_up">
            <a href="/register">Sign up</a>
        </div>
    </div>
</body>
</html><?php /**PATH C:\OSPanel\domains\basecam.uz\resources\views/welcome.blade.php ENDPATH**/ ?>